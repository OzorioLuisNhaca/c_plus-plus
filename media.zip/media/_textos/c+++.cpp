#include <iostream>
using namespace std;

int main(){
	cout<<"Ola Mundo";
	return 0;
}