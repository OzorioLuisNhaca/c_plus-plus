function mudaFoto(foto){
		document.getElementById("icone").src=foto;
	}