package primeiroprograma;
public class PrimeiroPrograma {
	public static void main(String[] args){
		System.out.print("Ola, Mundo");
	}
}